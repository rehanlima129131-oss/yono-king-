<?php
/**
 * AppZone functions and definitions
 *
 * @package AppZone
 */

function appzone_enqueue_styles() {
    wp_enqueue_style( 'appzone-pages', get_template_directory_uri() . '/css/pages.css' );
    wp_enqueue_style( 'appzone-style', get_template_directory_uri() . '/css/style.css' );
    wp_enqueue_style( 'appzone-main', get_stylesheet_uri() );
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css' );
    wp_enqueue_style( 'google-fonts', 'https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&family=Poppins:wght@400;600;700&display=swap' );
}
add_action( 'wp_enqueue_scripts', 'appzone_enqueue_styles' );

function appzone_enqueue_scripts() {
    wp_enqueue_script( 'appzone-apps', get_template_directory_uri() . '/js/apps.js', array(), '1.0.0', true );
    wp_enqueue_script( 'appzone-main', get_template_directory_uri() . '/js/main.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'appzone_enqueue_scripts' );

function appzone_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
}
add_action( 'after_setup_theme', 'appzone_setup' );
