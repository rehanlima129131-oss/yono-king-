// =========================================
// main.js  –  UI logic
// =========================================

let currentTab = 'all';

// ---- Render app list ----
function renderApps(tab) {
  const list = document.getElementById('appList');
  if (!list) return;

  const filtered = (tab === 'all')
    ? APPS
    : APPS.filter(a => a.tag === tab || a.tag === 'all');

  if (filtered.length === 0) {
    list.innerHTML = '<p style="text-align:center;padding:30px;color:#6b6b8a;">No apps found.</p>';
    return;
  }

  list.innerHTML = filtered.map(app => `
    <li class="app-item">
      <div class="app-left">
        <img
          class="app-icon"
          src="${app.iconFallback}"
          alt="${app.name} icon"
          onerror="this.src='${app.iconFallback}'"
        />
        <div class="app-info">
          <h3>
            ${app.name}
            ${app.tag === 'new' ? '<span class="new-badge">New</span>' : ''}
          </h3>
          <div class="app-bonus">
            <i class="fas fa-gift"></i> Sign Up Bonus ${app.bonus}
          </div>
          <div class="app-withdraw">
            <i class="fas fa-building-columns"></i> Min. Withdraw ${app.withdraw}
          </div>
        </div>
      </div>
      <button
        class="download-btn"
        onclick="openPopup(${app.id})"
        aria-label="Download ${app.name}"
      >
        <i class="fas fa-download"></i> Download
      </button>
    </li>
  `).join('');
}

// ---- Tab switcher ----
function switchTab(tab, btn) {
  currentTab = tab;
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderApps(tab);
}

// ---- Popup ----
function openPopup(id) {
  const app = APPS.find(a => a.id === id);
  if (!app) return;

  document.getElementById('popupIcon').src = app.iconFallback;
  document.getElementById('popupIcon').onerror = function() { this.src = app.iconFallback; };
  document.getElementById('popupTitle').textContent = app.name;
  document.getElementById('popupRating').textContent = app.rating;
  document.getElementById('popupSize').textContent = app.size;
  document.getElementById('popupBonus').textContent = app.bonus;
  document.getElementById('popupLink').href = app.link;

  document.getElementById('popup').classList.add('open');
  history.pushState({ popup: true }, '', '#popup');
}

function closePopup() {
  document.getElementById('popup').classList.remove('open');
  if (location.hash === '#popup') history.back();
}

// close on backdrop click
document.getElementById('popup').addEventListener('click', function(e) {
  if (e.target === this) closePopup();
});

// close on browser back
window.addEventListener('popstate', function(e) {
  if (!e.state || !e.state.popup) closePopup();
});

// ---- Mobile nav toggle ----
function toggleMenu() {
  document.getElementById('mobileNav').classList.toggle('open');
}

// ---- Scroll to top ----
const scrollBtn = document.createElement('button');
scrollBtn.className = 'scroll-top';
scrollBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
scrollBtn.setAttribute('aria-label', 'Scroll to top');
scrollBtn.onclick = () => window.scrollTo({ top: 0, behavior: 'smooth' });
document.body.appendChild(scrollBtn);

window.addEventListener('scroll', () => {
  scrollBtn.classList.toggle('visible', window.scrollY > 300);
});

// ---- Init ----
document.addEventListener('DOMContentLoaded', () => {
  renderApps('all');
});
