// =========================================
// apps.js  –  Your app data goes here
// Add, remove, or edit apps in this array
// =========================================

const APPS = [
  {
    id: 1,
    name: "Lucky Rummy",
    icon: "images/lucky-rummy.png",   // replace with real image path
    iconFallback: "https://via.placeholder.com/58x58/6C3EF6/fff?text=LR",
    bonus: "₹100",
    withdraw: "₹100",
    rating: "4.5",
    size: "62 MB",
    tag: "new",          // "new", "popular", or "all"
    link: "#"            // replace with real download link
  },
  {
    id: 2,
    name: "Spin Mania",
    icon: "images/spin-mania.png",
    iconFallback: "https://via.placeholder.com/58x58/FF6B35/fff?text=SM",
    bonus: "₹77",
    withdraw: "₹100",
    rating: "4.4",
    size: "58 MB",
    tag: "popular",
    link: "#"
  },
  {
    id: 3,
    name: "Arcade Rush",
    icon: "images/arcade-rush.png",
    iconFallback: "https://via.placeholder.com/58x58/9b5de5/fff?text=AR",
    bonus: "₹50",
    withdraw: "₹100",
    rating: "4.3",
    size: "75 MB",
    tag: "all",
    link: "#"
  },
  {
    id: 4,
    name: "Teen Patti Pro",
    icon: "images/teenpatti-pro.png",
    iconFallback: "https://via.placeholder.com/58x58/e63946/fff?text=TP",
    bonus: "₹30",
    withdraw: "₹100",
    rating: "4.2",
    size: "80 MB",
    tag: "popular",
    link: "#"
  },
  {
    id: 5,
    name: "Slots Galaxy",
    icon: "images/slots-galaxy.png",
    iconFallback: "https://via.placeholder.com/58x58/00b37e/fff?text=SG",
    bonus: "₹45",
    withdraw: "₹100",
    rating: "4.1",
    size: "68 MB",
    tag: "all",
    link: "#"
  },
  {
    id: 6,
    name: "Jackpot 777",
    icon: "images/jackpot-777.png",
    iconFallback: "https://via.placeholder.com/58x58/ffd166/333?text=J7",
    bonus: "₹191",
    withdraw: "₹100",
    rating: "4.6",
    size: "72 MB",
    tag: "new",
    link: "#"
  },
  {
    id: 7,
    name: "Rummy Star",
    icon: "images/rummy-star.png",
    iconFallback: "https://via.placeholder.com/58x58/6C3EF6/fff?text=RS",
    bonus: "₹50",
    withdraw: "₹100",
    rating: "4.4",
    size: "65 MB",
    tag: "all",
    link: "#"
  },
  {
    id: 8,
    name: "Win Zone",
    icon: "images/win-zone.png",
    iconFallback: "https://via.placeholder.com/58x58/FF6B35/fff?text=WZ",
    bonus: "₹38",
    withdraw: "₹100",
    rating: "4.2",
    size: "70 MB",
    tag: "new",
    link: "#"
  }
];
