# AppZone – App Listing Website

A complete, original app listing website. All files are 100% yours to customise.

---

## 📁 File Structure

```
app-listing-site/
│
├── index.html          ← Main homepage (app list + tabs + popup)
├── about.html          ← About Us page
├── contact.html        ← Contact form page
├── privacy.html        ← Privacy Policy page
├── terms.html          ← Terms & Conditions page
├── disclaimer.html     ← Disclaimer page
├── blog.html           ← Blog listing page
│
├── css/
│   ├── style.css       ← Main styles (header, hero, app list, popup, footer)
│   └── pages.css       ← Inner page styles (about, contact, blog, forms)
│
├── js/
│   ├── apps.js         ← ⭐ YOUR APP DATA – edit this file to add/remove apps
│   └── main.js         ← UI logic (render, tabs, popup, scroll-to-top)
│
└── images/             ← Put your app icon images here
```

---

## ✏️ How to Add Apps

Open `js/apps.js` and add a new object to the `APPS` array:

```js
{
  id: 9,                          // unique number
  name: "My New App",
  icon: "images/my-app.png",      // local image path
  iconFallback: "https://...",    // fallback URL if local missing
  bonus: "₹75",
  withdraw: "₹100",
  rating: "4.3",
  size: "65 MB",
  tag: "new",                     // "new", "popular", or "all"
  link: "https://your-link.com"   // real download/affiliate link
}
```

---

## 🎨 Customise Colours

In `css/style.css`, edit the `:root` variables at the top:

```css
--primary:   #6C3EF6;   /* main purple */
--accent:    #FF6B35;   /* orange accent */
--bg:        #F7F5FF;   /* page background */
```

---

## 🚀 How to Use

1. Upload all files to your web hosting (keep the folder structure intact).
2. Edit `js/apps.js` to add your real app links and icons.
3. Replace placeholder emails in footer/contact with your real contact details.
4. Done!

---

© 2025 AppZone – Your original site, built from scratch.
